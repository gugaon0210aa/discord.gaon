# discord.gaon

`discord.gaon` is a simple Discord bot library.

## Installation

```bash
pip install discord.gaon
